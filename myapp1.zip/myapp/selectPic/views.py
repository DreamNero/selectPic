# Create your views here.

from models import pic
from django.shortcuts import render, redirect , render_to_response
from django.http import HttpResponse
import json


def index(request):
    return render(request, 'index.html')


def save(request):
    num=request.GET.get('num')
    p=pic()
    p.ids=num
    p.save()
    return HttpResponse('Done')

