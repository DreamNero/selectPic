// item selection
$$('img').click(function () {
  $$(this).parent().toggleClass('selected');
  if ($$('li.selected').length == 0)
    $$('.select').removeClass('selected');
  else
    $$('.select').addClass('selected');
  counter();
});

// all item selection
$$('.select').click(function () {
  if ($$('li.selected').length == 0) {
    $$('li').addClass('selected');
    $$('.select').addClass('selected');
  }
  else {
    $$('li').removeClass('selected');
    $$('.select').removeClass('selected');
  }
  counter();
});

// number of selected items
function counter() {
  if ($$('li.selected').length > 0)
    $$('.send').addClass('selected');
  else
    $$('.send').removeClass('selected');
  $$('.send').attr('data-counter',$$('li.selected').length);
}

$$('.send').click(function () {
  var a="";
  for(i=0;i<$$('li.selected').length;i++){
    a= (a + $$('li.selected').eq(i).children().eq(0).attr('id')) + (((i + 1)== $$('li.selected').length) ? '':',');
  }
  if($$('.send.selected').length>0)
      $.get('/save',{num:a}, function (data) {
        alert(data);
  });
});

