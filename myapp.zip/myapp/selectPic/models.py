from django.db import models

# Create your models here.
class pic(models.Model):
    #index = models.PositiveIntegerField(primary_key=True, unique=True)

    ids = models.CharField(max_length=100)
    class Meta:
        db_table = 'pic'